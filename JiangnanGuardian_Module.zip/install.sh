#!/sbin/sh
#
# 江南护法 - Magisk模块
# 作者：王听
# 仅供学习研究使用，请勿用于违法行为
#

set -e

SKIPUNZIP=0

ui_print "*****************************************"
ui_print "  江南护法 - SoterService拦截器模块"
ui_print "  作者：王听"
ui_print "  版本：v1.0"
ui_print "*****************************************"
ui_print "该模块仅用于学习研究，请勿用于违法行为"
ui_print "出现问题自负"
ui_print "*****************************************"
ui_print "正在安装..."

# 提取模块文件
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'JiangnanGuardian.apk' -d $MODPATH >&2

# 设置权限
set_perm_recursive $MODPATH 0 0 0755 0644

ui_print "安装完成！"
ui_print "请重启设备以激活模块"
